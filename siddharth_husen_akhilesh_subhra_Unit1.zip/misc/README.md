# SE_PROJECT

Change path in BowlerFile.java (private static String BOWLER_DAT="absolute path to your location")

# Github link

https://github.com/sidgupta2205/SE_PROJECT